/* tslint:disable */
/* eslint-disable */
export function check_composed_projection(protos: InterfacingProtocols, subs: string, role: Role, machine: ProtocolType): CheckResult;
export function check_composed_swarm(protos: InterfacingProtocols, subs: string): CheckResult;
export function compose_protocols(protos: InterfacingProtocols): DataResult;
export function overapproximated_well_formed_sub(protos: InterfacingProtocols, subs: string, granularity: Granularity): DataResult;
export function revised_projection(proto: ProtocolType, subs: string, role: Role, minimize: boolean): DataResult;
export function exact_well_formed_sub(protos: InterfacingProtocols, subs: string): DataResult;
export function project_combine(protos: InterfacingProtocols, subs: string, role: Role, minimize: boolean): DataResult;
export function projection_information(role: Role, protos: InterfacingProtocols, k: number, subs: string, machine: ProtocolType, minimize: boolean): DataResult;
export function check_projection(swarm: ProtocolType, subs: string, role: Role, machine: ProtocolType): CheckResult;
export function check_swarm(proto: ProtocolType, subs: string): CheckResult;
export function well_formed_sub(proto: ProtocolType, subs: string): DataResult;
export type SpecialEventTypes = EventType[];

export interface ProjectionInfo {
    projection: MachineType;
    branches: BranchMap;
    specialEventTypes: SpecialEventTypes;
    projToMachineStates: ProjToMachineStates;
}

export type BranchMap = Record<EventType, EventType[]>;

export interface CompositionComponent<T> {
    protocol: SwarmProtocolType;
    interface: T | null;
}

export type ProjToMachineStates = Record<State, State[]>;

export type InterfacingSwarms<T> = CompositionComponent<T>[];

export type Granularity = "Fine" | "Medium" | "Coarse" | "TwoStep";

export type InterfacingProtocols = SwarmProtocolType[];

export interface SwarmLabel {
    cmd: Command;
    logType: EventType[];
    role: Role;
}

export type DataResult<T> = { type: "OK"; data: T } | { type: "ERROR"; errors: string[] };

export type Command = InternedHash<string>;

export type EventType = InternedHash<string>;

export interface ProtocolType<L> {
    initial: State;
    transitions: Transition<L>[];
}

export type CheckResult = { type: "OK" } | { type: "ERROR"; errors: string[] };

export type MachineLabel = { tag: "Execute"; cmd: Command; logType: EventType[] } | { tag: "Input"; eventType: EventType };

export type Role = InternedHash<string>;

export type State = InternedHash<string>;

export interface Transition<L> {
    label: L;
    source: State;
    target: State;
}

export type MachineType = ProtocolType<MachineLabel>;

export type Subscriptions = Record<Role, EventType[]>;

export type SwarmProtocolType = ProtocolType<SwarmLabel>;

