import { MachineEvent } from '../index.js';
import { MachineRunner, State, SubscribeFn } from '../runner/runner.js';
import { CommandDefinerMap, Contained, StateFactory } from '../design/state.js';
import { RetvalOrElse } from '../utils/type-utils.js';
/**
 * Detached machine runner used for unit tests. Events coming into the machine
 * are manually fed instead of being supplied by Actyx.
 */
export type MockMachineRunner<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateUnion extends unknown> = MachineRunner<SwarmProtocolName, MachineName, StateUnion> & {
    /**
     * Contains test utilities for MockMachineRunner
     * @see MockMachineRunnerTestUtils for more information
     */
    test: MockMachineRunnerTestUtils<SwarmProtocolName, MachineName, MachineEventFactories>;
    /**
     * Add type refinement to the state payload produced by the mock
     * machine-runner
     *
     * @param stateFactories - All state factories produced by the
     * MachineProtocol. All state factories must be included, otherwise (i.e.
     * passing only some state factories) will result in an exception being
     * thrown.
     * @return a reference the mock machine-runner instance with added type
     * refinement
     *
     * @example
     * const machineRunner = createMockMachineRunner(StateA, undefined)
     *  .refineStateType([StateA, StateB, StateC] as const);
     *
     * const stateSnapshot = machineRunner.get();
     * if (!stateSnapshot) return
     *
     * const payload = stateSnapshot.payload; // union of payloads of StateA, StateB, and StateC
     */
    refineStateType: <Factories extends Readonly<StateFactory<SwarmProtocolName, MachineName, any, any, any, any>[]>>(_: Factories) => MockMachineRunner<SwarmProtocolName, MachineName, MachineEventFactories, StateFactory.ReduceIntoPayload<Factories>>;
};
/**
 * Contains test utilities for MockMachineRunner
 */
type MockMachineRunnerTestUtils<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any> = {
    /**
     * Feed events into the MachineRunner.
     * @example
     * const machineRunner = createMockMachineRunner(Passenger.Initial, void 0)
     *
     * machineRunner.test.feed([
     *   Requested.make({
     *     destination: requestDestination,
     *     pickup: requestPickup,
     *   }),
     *   Bid.make({
     *     price: bidPrice,
     *     time: bidTime.toISOString(),
     *   }),
     *   BidderID.make({
     *     id: bidderId,
     *   }),
     * ])
     */
    feed: (ev: MachineEvent.Of<MachineEventFactories>[], props?: {
        caughtUp: boolean;
    }) => ReturnType<Subscription.CallbackFnOf<MachineEvent.Of<MachineEventFactories>>>;
    /**
     * Asserts the state of the machine as being in the state  of a particular
     * StateFactory.
     * @example
     * const auction = machineRunner.test.assertAs(Passenger.Auction, (auction) => {
     *   expect(auction.payload.bids.at(0)).toEqual({
     *     bidderID: bidderId,
     *     time: bidTime,
     *     price: bidPrice,
     *   } as BidData)
     *
     *   return auction
     * })
     *
     * @example
     * const auction = machineRunner.test.assertAs(Passenger.Auction)
     * expect(auction.payload.bids.at(0)).toEqual({
     *   bidderID: bidderId,
     *   time: bidTime,
     *   price: bidPrice,
     * } as BidData)
     */
    assertAs: <N extends string, P, C extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>, Then extends (state: State<N, P, C>) => any>(...args: [StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, N, P, C>] | [StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, N, P, C>, Then]) => RetvalOrElse<typeof args[1], State<N, P, C>>;
};
export type MockMachineRunnerDelayUtils = {
    toggle: PromiseDelay['toggle'];
};
/**
 * Creates a MockMachineRunner. This function intended as the equivalent of
 * createMachineRunner for unit-testing purpose.
 * @see MockMachineRunner for more information
 * @example
 * const machineRunner = createMockMachineRunner(Passenger.Initial, void 0)
 */
export declare const createMockMachineRunner: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, Payload, StateUnion extends unknown>(factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, string, Payload, object>, payload: Payload) => MockMachineRunner<SwarmProtocolName, MachineName, MachineEventFactories, StateUnion>;
export declare const mockMeta: () => {
    isLocalEvent: boolean;
    tags: never[];
    timestampMicros: number;
    timestampAsDate: () => Date;
    lamport: number;
    eventId: string;
    appId: string;
    stream: string;
    offset: number;
};
type PromiseDelay = ReturnType<typeof PromiseDelay['make']>;
export declare namespace PromiseDelay {
    type Pair = [
        Promise<void>,
        {
            resolve: () => void;
            reject: () => void;
            isFinished: () => boolean;
        }
    ];
    export const make: () => {
        make: () => Pair;
        toggle: (delayControl: {
            delaying: true;
        } | {
            delaying: false;
            reject?: boolean;
        }) => Promise<void>;
    };
    export {};
}
export declare namespace Subscription {
    type CallbackFnOf<MachineEvents extends MachineEvent.Any> = Parameters<SubscribeFn<MachineEvents>>[0];
    const make: <MachineEvents extends MachineEvent.Any>() => {
        cb: null | ((data: import("@actyx/sdk").EventsOrTimetravel<MachineEvents>) => Promise<void>);
        err: null | Exclude<import("@actyx/sdk").OnCompleteOrErr | undefined, undefined>;
        cancel: () => void;
        subscribe: SubscribeFn<MachineEvents>;
    };
}
export {};
