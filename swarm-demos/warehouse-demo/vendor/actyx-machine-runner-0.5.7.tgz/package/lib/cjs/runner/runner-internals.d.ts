import { ActyxEvent, Metadata } from '@actyx/sdk';
import { CommandDefinerMap, CommandGeneratorCriteria } from '../design/command.js';
import { Contained, MachineEvent } from '../design/event.js';
import { StateRaw, StateRawBT, StateFactory } from '../design/state.js';
import { Destruction } from '../utils/destruction.js';
import { MachineRunnerFailure } from '../errors.js';
export type CommandCallback<MachineEventFactories extends MachineEvent.Factory.Any> = (_: {
    commandKey: string;
    commandGeneratorCriteria: CommandGeneratorCriteria;
    generateEvents: () => Contained.ContainedEvent<MachineEvent.Of<MachineEventFactories>>[];
}) => Promise<Metadata[]>;
export type RunnerInternals<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = {
    destruction: Destruction;
    caughtUpFirstTime: boolean;
    caughtUp: boolean;
    readonly initial: StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, any, any>;
    commandEmitFn: CommandCallback<MachineEventFactories>;
    queue: ActyxEvent<MachineEvent.Any>[];
    current: StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    previouslyEmittedToNext: null | StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    commandLock: null | symbol;
    /**
     * When not null: indicates that the machine is failing from a miscalculation
     * inside a reaction
     */
    failure: null | MachineRunnerFailure;
};
export declare namespace RunnerInternals {
    type Any = RunnerInternals<any, any, any, any, any, any>;
    const make: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload extends any, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>, payload: StatePayload, commandCallback: CommandCallback<MachineEventFactories>) => RunnerInternals<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    const reset: (internals: RunnerInternals.Any) => void;
    const pushEvent: <StatePayload>(internals: RunnerInternals.Any, event: ActyxEvent<MachineEvent.Any>) => PushEventResult;
}
export type StateAndFactory<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload extends any, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = {
    factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    data: StateRaw<any, any> | StateRawBT<any, any>;
};
export declare namespace StateAndFactory {
    type Any = StateAndFactory<any, any, any, any, any, any>;
}
export declare namespace PushEventTypes {
    const Discard: unique symbol;
    type Discard = typeof Discard;
    const Push: unique symbol;
    type Push = typeof Push;
    const React: unique symbol;
    type React = typeof React;
    const Failure: unique symbol;
    type Failure = typeof Failure;
}
export type PushEventResult = {
    type: PushEventTypes.Push;
} | {
    type: PushEventTypes.Discard;
    discarded: ActyxEvent<MachineEvent.Any>;
} | {
    type: PushEventTypes.React;
    triggeringEvents: ActyxEvent<MachineEvent.Any>[];
} | {
    type: PushEventTypes.Failure;
    failure: {
        error: unknown;
        current: StateFactory.Any;
        next: StateFactory.Any;
    };
};
/**
   * Branch-tracking version of RunnerInternals.
   * Difference between this and original:
   *  - RunnerInternalsBT has an additional jbLast field, which is a Map<string, string>. We use it to map event types to events.
   *  - RunnerInternalsBT uses the jbLast field to determine if an event should be enqueued: events are enqueued if they have the correct pointer
   *
   */
export type RunnerInternalsBT<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = {
    destruction: Destruction;
    caughtUpFirstTime: boolean;
    caughtUp: boolean;
    readonly initial: StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, any, any>;
    commandEmitFn: CommandCallback<MachineEventFactories>;
    queue: ActyxEvent<MachineEvent.Any>[];
    current: StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    previouslyEmittedToNext: null | StateAndFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    commandLock: null | symbol;
    /**
     * When not null: indicates that the machine is failing from a miscalculation
     * inside a reaction
     */
    failure: null | MachineRunnerFailure;
    branchTracker: RunnerInternalsBT.BranchTracker;
};
export declare namespace RunnerInternalsBT {
    type Any = RunnerInternalsBT<any, any, any, any, any, any>;
    type BranchTracker = {
        readonly jbLast: Map<string, string>;
        readonly specialEventTypes: Set<string>;
        readonly branches: Record<string, string[]>;
    };
    const make: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload extends any, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>, payload: StatePayload, specialEventTypes: Set<string>, branches: Record<string, string[]>, commandCallback: CommandCallback<MachineEventFactories>) => RunnerInternalsBT<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    const reset: (internals: RunnerInternalsBT.Any) => void;
    const pushEvent: <StatePayload>(internals: RunnerInternalsBT.Any, event: ActyxEvent<MachineEvent.Any>) => PushEventResult;
}
