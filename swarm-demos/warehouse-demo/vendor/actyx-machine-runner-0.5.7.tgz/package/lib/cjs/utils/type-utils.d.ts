export type DeepReadonly<T> = {
    readonly [P in keyof T]: T[P] extends Record<string, unknown> ? DeepReadonly<T[P]> : T[P];
};
export type ReadonlyNonZeroTuple<T> = Readonly<[T, ...T[]]>;
export type NonZeroTuple<T> = [T, ...T[]];
export type RetvalOrElse<T, Else> = T extends (...args: any[]) => infer Retval ? Retval : Else;
export type ExtendsThenTransform<A, B, T = true, F = false> = [A] extends [B] ? T : F;
export type Equal<X, Y> = (<T>() => T extends X ? 1 : 2) extends <T>() => T extends Y ? 1 : 2 ? true : false;
export type NotEqual<X, Y> = true extends Equal<X, Y> ? false : true;
export type Expect<T extends true> = T;
export type NotAnyOrUnknown<T> = any extends T ? never : T;
export type SerializableValue = string | number | boolean | null | SerializableObject | SerializableArray;
export type SerializableArray = SerializableValue[];
export type SerializableObject = {
    [key: string]: SerializableValue;
} & {
    [key: symbol]: never;
};
