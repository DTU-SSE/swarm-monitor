export declare class MachineRunnerError extends Error {
    constructor(message?: string);
}
export declare class MachineRunnerErrorCommandFiredAfterLocked extends MachineRunnerError {
    constructor(message?: string);
}
export declare class MachineRunnerErrorCommandFiredAfterDestroyed extends MachineRunnerError {
    constructor(message?: string);
}
export declare class MachineRunnerErrorCommandFiredAfterExpired extends MachineRunnerError {
    constructor(message?: string);
}
export declare class MachineRunnerErrorCommandFiredWhenNotCaughtUp extends MachineRunnerError {
    constructor(message?: string);
}
export declare class MachineRunnerFailure extends MachineRunnerError {
    cause: unknown;
    constructor(message?: string, cause?: unknown);
}
