import { ActiveRunnerRegistryRegisterSymbol, GlobalEmitter } from './runner/runner-utils.js';
import type { MachineRunner } from './runner/runner.js';
import type { Tags } from '@actyx/sdk';
import type { StateFactory } from './design/state.js';
export declare const emitter: GlobalEmitter;
export type ActiveRunnerRegistry = {
    all: () => [MachineRunner.Any, ActiveRunnerRegistryDetail][];
    [ActiveRunnerRegistryRegisterSymbol]: (machine: MachineRunner.Any, detail: ActiveRunnerRegistryDetail) => void;
};
export type ActiveRegistryRunnerEntry = [MachineRunner.Any, ActiveRunnerRegistryDetail];
export type ActiveRunnerRegistryDetail = {
    tags: Tags;
    initialFactory: StateFactory.Any;
};
/**
 * Contains all active machine runners. Use `.all` method to get all active
 * machine-runners and its details
 *
 * @example
 * // Monitoring active machine runners
 *
 * while (true) {
 *  activeRunners.all().forEach(([machine, detail]) => {
 *    console.log(machine, detail)
 *  })
 *
 *  await new Promise(res => setTimeout(res, 1000))
 * }
 */
export declare const activeRunners: ActiveRunnerRegistry;
