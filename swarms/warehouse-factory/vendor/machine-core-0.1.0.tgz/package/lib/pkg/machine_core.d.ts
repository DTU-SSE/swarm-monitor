/* tslint:disable */
/* eslint-disable */
export type EventType = InternedHash<string>;

export type ProjToMachineStates = Record<State, State[]>;

export type SubscriptionsWrapped = Record<Role, EventType[]>;

export type DataResult<T> = { type: "OK"; data: T } | { type: "ERROR"; errors: string[] };

export interface Transition<L> {
    label: L;
    source: State;
    target: State;
}

export type Command = InternedHash<string>;

export type SwarmProtocolType = ProtocolType<SwarmLabel>;

export type Granularity = "Fine" | "Coarse" | "TwoStep";

export type MachineType = ProtocolType<MachineLabel>;

export type InterfacingProtocols = SwarmProtocolType[];

export interface ProjectionInfo {
    projection: MachineType;
    branches: BranchMap;
    specialEventTypes: SpecialEventTypes;
    projToMachineStates: ProjToMachineStates;
}

export type MachineLabel = { tag: "Execute"; cmd: Command; logType: EventType[] } | { tag: "Input"; eventType: EventType };

export type BranchMap = Record<EventType, EventType[]>;

export interface SwarmLabel {
    cmd: Command;
    logType: EventType[];
    role: Role;
}

export type Role = InternedHash<string>;

export type SpecialEventTypes = EventType[];

export interface ProtocolType<L> {
    initial: State;
    transitions: Transition<L>[];
}

export type State = InternedHash<string>;


export function compose_protocols(protos: InterfacingProtocols): DataResult;

export function exact_well_formed_sub(protos: InterfacingProtocols, subs: SubscriptionsWrapped): DataResult;

export function overapproximated_well_formed_sub(protos: InterfacingProtocols, subs: SubscriptionsWrapped, granularity: Granularity): DataResult;

export function project(protos: InterfacingProtocols, subs: SubscriptionsWrapped, role: Role, minimize: boolean, expand_protos: boolean): DataResult;

export function projection_information(role: Role, protos: InterfacingProtocols, k: number, subs: SubscriptionsWrapped, machine: ProtocolType, minimize: boolean): DataResult;
