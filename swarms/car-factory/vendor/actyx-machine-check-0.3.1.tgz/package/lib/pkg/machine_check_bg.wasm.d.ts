/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const check_composed_projection: (a: any, b: any, c: any, d: any) => any;
export const check_composed_swarm: (a: any, b: any) => any;
export const check_projection: (a: any, b: any, c: any, d: any) => any;
export const check_swarm: (a: any, b: any) => any;
export const well_formed_sub: (a: any, b: any) => any;
export const compose_protocols: (a: any) => any;
export const exact_well_formed_sub: (a: any, b: any) => any;
export const overapproximated_well_formed_sub: (a: any, b: any, c: any) => any;
export const project: (a: any, b: any, c: any, d: number, e: number) => any;
export const projection_information: (a: any, b: any, c: number, d: any, e: any, f: number) => any;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_start: () => void;
