import { Tags } from '@actyx/sdk';
import { StateMechanism, MachineProtocol, StateFactory, CommandDefinerMap } from './state.js';
import { Contained, MachineEvent } from './event.js';
import { Subscriptions, ProjectionInfo, InterfacingProtocols } from 'machine-core';
/**
 * SwarmProtocol is the entry point of designing a swarm of MachineRunners. A
 * SwarmProtocol dictates MachineEvents used for communication and Actyx Tags
 * used as the channel to transport said Events. A SwarmProtocol provides a way
 * to design Machine protocols that abides the Events and Tags rules of the
 * SwarmProtocol and a way to adapt machines to composed swarms.
 *
 * #### Example: creating a Swarm Protocol and a Machine
 * ```ts
 * const protocol = SwarmProtocol.make("HangarBayExchange")
 * const machine = protocol.makeMachine("HangarBay")
 * ```
 * #### Example: adapting a Machine
 * ```ts
 * // Define events emitted in a swarm
 * const partReq = MachineEvent.design('partReq').withoutPayload()
 * const partOK = MachineEvent.design('partOK').withoutPayload()
 * const pos = MachineEvent.design('pos').withoutPayload()
 * const closingTime = MachineEvent.design('closingTime').withPayload<{ timeOfDay: string }>()
 *
 * // Specify the shape of a swarm protocol
 * const warehouse: SwarmProtocolType = {
 *   initial: '0',
 *   transitions: [
 *     {source: '0', target: '1', label: {cmd: 'request', role: 'T', logType: [partReq.type]}},
 *     {source: '1', target: '2', label: {cmd: 'get', role: 'FL', logType: [pos.type]}},
 *     {source: '2', target: '0', label: {cmd: 'deliver', role: 'T', logType: [partOK.type]}},
 *     {source: '0', target: '3', label: {cmd: 'close', role: 'D', logType: [closingTime.type]}},
 * ]}
 *
 * // Implement the machine 'door' for the swarm protocol 'warehouse'
 * const door = composition.makeMachine('Door')
 * const s0 = door.designEmpty('s0')
 *   .command('close', [Events.closingTime], () => {
 *       const dateString = new Date().toString();
 *       return [Events.closingTime.make({timeOfDay: dateString})]})
 *   .finish()
 * const s1 = door.designEmpty('s1').finish()
 * const s2 = door.designEmpty('s2').finish()
 *
 * s0.react([Events.partReq], s1, () => { return s1.make() })
 * s1.react([Events.partOK], s0, () => { return s0.make() })
 * s0.react([Events.closingTime], s2, () => { return s2.make() })
 *
 * // Specify the shape of another swarm protocol that can be composed with 'warehouse'
 * // and an event from this swarm protocol.
 * const factory: SwarmProtocolType = {
 *   initial: '0',
 *   transitions: [
 *     {source: '0', target: '1', label: { cmd: 'request', role: 'T', logType: [partReq.type]}},
 *     {source: '1', target: '2', label: { cmd: 'deliver', role: 'T', logType: [partOK.type]}},
 *     {source: '2', target: '3', label: { cmd: 'build', role: 'R', logType: [car.type] }},
 * ]}
 *
 * const car = MachineEvent.design('car').withoutPayload()
 *
 * // Instantiate a SwarmProtocol for running the swarm composed from 'warehouse' and 'factory'
 * const allEvents = [partReq, partOK, pos, closingTime, car] as const
 * const composition = SwarmProtocol.make('Composition', allEvents)
 *
 * // Generate a subscription that can be used by machines implementing the composed swarm protocol.
 * const protocols: InterfacingProtocols = [warehouse, factory]
 * const subscriptionsResult: DataResult<Subscriptions> = overapproxWWFSubscriptions(protocols, {}, 'Medium')
 * if (subscriptionsResult.type === 'ERROR') throw new Error(subscriptionsResult.errors.join(', '))
 * const subscriptions: Subscriptions = subscriptionsResult.data
 *
 * // Adapt 'door' to the composition of 'warehouse' and 'factory'
 * const [doorAdapted, s0Adapted] = composition.adaptMachine('D', protocols, 0, subscriptions, [door, s0])
 * ```
 */
export type SwarmProtocol<SwarmProtocolName extends string, MachineEventFactories extends MachineEvent.Factory.Any, MachineEvents extends MachineEvent.Any = MachineEvent.Of<MachineEventFactories>> = {
    makeMachine: <MachineName extends string>(machineName: MachineName) => Machine<SwarmProtocolName, MachineName, MachineEventFactories>;
    tagWithEntityId: (id: string) => Tags<MachineEvents>;
    /**
     * Adapt a machine.
     * @param role - The role implemented by the machine.
     * @param protocols - The protocols forming the composition that the machine is adapted to.
     * @param k - An index pointing into 'protocols' indicating the swarm protocol 'mOld' was implemented for.
     * @param subscriptions - A map associating each role with the set of event types they receive.
     * @param mOld - The machine to adapt.
     * @param verbose - A verbose machine prints information on event emission and reception and on state changes.
     * @returns a {@link MachineResult} containing an {@link AdaptedMachine} on success and a list of error messages otherwise.
     */
    adaptMachine: <MachineName extends string, ProjectionName extends string, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(role: ProjectionName, protocols: InterfacingProtocols, k: number, subscriptions: Subscriptions, mOld: [Machine<SwarmProtocolName, MachineName, MachineEventFactories>, StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, any, any>], verbose?: boolean) => MachineResult<[AdaptedMachine<SwarmProtocolName, ProjectionName, MachineEventFactories>, StateFactory<SwarmProtocolName, ProjectionName, MachineEventFactories, StateName, StatePayload, Commands>]>;
};
/**
 * Utilities for SwarmProtocol
 * @see SwarmProtocol.make
 */
export declare namespace SwarmProtocol {
    /**
     * Construct a SwarmProtocol
     * @param swarmName - The name of the swarm protocol
     * @param tagString - the base tag used to mark the events passed to Actyx
     * @param registeredEventFactories - MachineEvent.Factories that are allowed
     * to be used for communications in the scope of this SwarmProtocol
     * @example
     * const HangarDoorTransitioning = MachineEvent
     *   .design("HangarDoorTransitioning")
     *   .withPayload<{ fractionOpen: number }>()
     * const HangarDoorClosed = MachineEvent
     *   .design("HangarDoorClosed")
     *   .withoutPayload()
     * const HangarDoorOpen = MachineEvent
     *   .design("HangarDoorOpen")
     *   .withoutPayload()
     *
     * // Creates a protocol
     * const HangarBay = SwarmProtocol.make(
     *   'HangarBay',
     *   [HangarDoorTransitioning, HangarDoorClosed, HangarDoorOpen]
     * )
     */
    const make: <SwarmProtocolName extends string, InitialEventFactoriesTuple extends MachineEvent.Factory.ReadonlyNonZeroTuple>(swarmName: SwarmProtocolName, registeredEventFactories: InitialEventFactoriesTuple) => SwarmProtocol<SwarmProtocolName, MachineEvent.Factory.Reduce<InitialEventFactoriesTuple>>;
}
/**
 * A machine is the entry point for designing machine states and transitions.
 * Its name should correspond to a role definition in a machine-check swarm
 * protocol. The resulting states are constrained to only be able to interact
 * with the events listed in the protocol design step. It accumulates
 * information on states and reactions. This information can be passed to
 * checkProjection to verify that the machine fits into a given swarm protocol.
 */
export type Machine<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any> = Readonly<{
    swarmName: SwarmProtocolName;
    machineName: MachineName;
    /**
     * Starts the design process for a state with a payload. Payload data will be
     * required when constructing this state.
     * @example
     * const HangarControlIncomingShip = machine
     *   .designState("HangarControlIncomingShip")
     *   .withPayload<{
     *     shipId: string,
     *   }>()
     *   .finish()
     */
    designState: <StateName extends string>(stateName: StateName) => DesignStateIntermediate<SwarmProtocolName, MachineName, MachineEventFactories, StateName>;
    /**
     * Starts a design process for a state without a payload.
     * @example
     * const HangarControlIdle = machine
     *   .designEmpty("HangarControlIdle")
     *   .finish()
     */
    designEmpty: <StateName extends string>(stateName: StateName) => StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, void, Record<never, never>>;
    createJSONForAnalysis: (initial: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, any, any>) => MachineAnalysisResource;
}>;
/**
 * Interface representing adapted machines. Extends {@link Machine} to contain information used
 * for branch tracking and for associating states in an adapted machine with states
 * in the machine from which the adapted machine is derived.
 */
export interface AdaptedMachine<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any> extends Machine<SwarmProtocolName, MachineName, MachineEventFactories> {
    /**
     * The projectionInfo field contains information used for branch tracking
     * and a map associating states in an adapted machine with states
     * in the machine from which the adapted machine is derived.
     */
    readonly projectionInfo: ProjectionInfo;
}
type DesignStateIntermediate<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string> = {
    /**
     * Declare payload type for a state.
     */
    withPayload: <StatePayload extends any>() => StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Record<never, never>>;
};
/**
 * A collection of type utilities around Machine.
 */
export declare namespace Machine {
    type Any = Machine<any, any, any>;
    /**
     * Extract the type of registered MachineEvent of a machine protocol in the
     * form of a union type.
     * @example
     * const E1 = MachineEvent.design("E1").withoutPayload();
     * const E2 = MachineEvent.design("E2").withoutPayload();
     * const E3 = MachineEvent.design("E3").withoutPayload();
     *
     * const protocol = SwarmProtocol.make("HangarBayExchange", [E1, E2, E3]);
     *
     * const machine = protocol.makeMachine("somename");
     *
     * type AllEvents = Machine.EventsOf<typeof machine>;
     * // Equivalent of:
     * // MachineEvent.Of<typeof E1> | MachineEvent.Of<typeof E2> | MachineEvent.Of<typeof E3>
     * // { "type": "E1" }           | { "type": "E2" }           | { "type": "E3" }
     */
    type EventsOf<T extends Machine.Any> = T extends Machine<any, any, infer EventFactories> ? EventFactories : never;
}
export type ProjectionType = {
    initial: string;
    transitions: {
        source: string;
        target: string;
        label: {
            tag: 'Execute';
            cmd: string;
            logType: string[];
        } | {
            tag: 'Input';
            eventType: string;
        };
    }[];
};
export interface MachineAnalysisResource extends ProjectionType {
    subscriptions: string[];
}
export type MachineResult<T> = {
    type: 'OK';
    data: T;
} | {
    type: 'ERROR';
    errors: string[];
    data: undefined;
};
export declare namespace MachineAnalysisResource {
    const SyntheticDelimiter: "\u00A7";
    const syntheticEventName: (baseStateFactory: StateMechanism.Any | StateFactory.Any, modifyingEvents: Pick<MachineEvent.Factory.Any, "type">[]) => string;
    const fromMachineInternals: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any>(protocolInternals: MachineProtocol<SwarmProtocolName, MachineName, MachineEventFactories>, initial: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, any, any>) => MachineAnalysisResource;
}
export {};
